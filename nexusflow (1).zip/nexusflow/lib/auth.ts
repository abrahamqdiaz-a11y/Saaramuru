import { NextRequest } from 'next/server'
import prisma from './db'

export async function validateApiKey(request: NextRequest): Promise<boolean> {
  const authHeader = request.headers.get('authorization')
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false
  }

  const apiKey = authHeader.substring(7)
  
  try {
    const key = await prisma.apiKey.findUnique({
      where: { apiKey, isActive: true }
    })

    if (key) {
      // Update last used timestamp
      await prisma.apiKey.update({
        where: { id: key.id },
        data: { lastUsedAt: new Date() }
      })
      return true
    }
    
    return false
  } catch (error) {
    console.error('API key validation error:', error)
    return false
  }
}

export function unauthorized() {
  return Response.json(
    { success: false, error: 'Unauthorized. Please provide a valid API key.' },
    { status: 401 }
  )
}

export async function validateAdminPassword(password: string): Promise<boolean> {
  return password === process.env.ADMIN_PASSWORD
}
