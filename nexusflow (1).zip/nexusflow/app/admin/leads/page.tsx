import Link from 'next/link'
import prisma from '@/lib/db'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatDate } from '@/lib/utils'
import { ArrowLeft } from 'lucide-react'

export default async function AdminLeadsPage() {
  const leads = await prisma.lead.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="ghost" asChild className="mb-2">
                <Link href="/admin">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Dashboard
                </Link>
              </Button>
              <h1 className="text-3xl font-bold text-stone-900">Leads</h1>
              <p className="text-stone-600 mt-1">
                {leads.length} total leads
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>All Leads</CardTitle>
            <CardDescription>
              People who have reached out via the contact form
            </CardDescription>
          </CardHeader>
          <CardContent>
            {leads.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-stone-600">No leads yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Name</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Email</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Phone</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Service</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Status</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leads.map((lead) => (
                      <tr key={lead.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-stone-900">{lead.name}</p>
                            {lead.businessName && (
                              <p className="text-sm text-stone-500">{lead.businessName}</p>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">{lead.email}</td>
                        <td className="py-3 px-4 text-stone-600">{lead.phone || '—'}</td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-700">
                            {lead.serviceType?.replace('_', ' ') || 'Not specified'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${
                            lead.status === 'new' ? 'bg-green-50 text-green-700' :
                            lead.status === 'won' ? 'bg-blue-50 text-blue-700' :
                            'bg-stone-100 text-stone-600'
                          }`}>
                            {lead.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-sm text-stone-600">
                          {formatDate(lead.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
