# Make.com Scenario Examples

These are the most useful scenarios to set up for your NexusFlow MVP.

---

## Scenario 1: New Lead from Contact Form → Notify Team

**What it does:** When someone fills out your intake form, create a lead in NexusFlow and notify your team on Slack.

**Modules:**
1. Webhooks → Custom Webhook (trigger)
2. HTTP → Make a Request (create lead in NexusFlow)
3. Slack → Create a Message
4. Gmail → Send an Email (auto-reply to the lead)

**Configuration:**

### Module 2: HTTP Request to Create Lead
- URL: `https://your-site.netlify.app/api/webhooks/lead`
- Method: `POST`
- Headers:
  ```
  Authorization: Bearer YOUR_API_SECRET_KEY
  Content-Type: application/json
  ```
- Body:
  ```json
  {
    "name": "{{1.name}}",
    "email": "{{1.email}}",
    "phone": "{{1.phone}}",
    "businessName": "{{1.businessName}}",
    "serviceType": "{{1.serviceType}}",
    "leadSource": "contact_form",
    "message": "{{1.message}}"
  }
  ```

### Module 3: Slack Message
- Channel: `#new-leads` (or your channel)
- Message:
  ```
  🎉 New lead just came in!
  
  *{{1.name}}* ({{1.email}})
  Service: {{1.serviceType}}
  
  Message: "{{1.message}}"
  
  Give them a call: {{1.phone}}
  ```

### Module 4: Gmail Auto-Reply
- To: `{{1.email}}`
- Subject: `Thanks for reaching out!`
- Body:
  ```
  Hi {{1.name}},
  
  Thanks for your message! We got your request about {{1.serviceType}} and someone from our team will reach out within 24 hours.
  
  In the meantime, feel free to text us at (555) 123-4567 if it's urgent!
  
  Best,
  Your Firm Name Team
  ```

---

## Scenario 2: Email → Create Task → Assign to Team

**What it does:** When a client emails you, automatically create a task in NexusFlow and assign it to the right person.

**Modules:**
1. Gmail → Watch Emails
2. Router (split by subject keywords)
3. HTTP → Get Client Info
4. HTTP → Create Task
5. Slack → Notify Assignee
6. Gmail → Send Auto-Reply

**Configuration:**

### Module 1: Gmail Watch
- Folder: INBOX
- Criteria: Unread emails
- Maximum: 10

### Module 2: Router
**Route 1: Tax Documents**
- Condition: Subject contains "tax" OR "w-2" OR "1099"
- Set variable: `priority = high`
- Set variable: `task_type = review_documents`

**Route 2: Billing Questions**
- Condition: Subject contains "billing" OR "invoice" OR "payment"
- Set variable: `priority = medium`
- Set variable: `task_type = answer_billing`

**Route 3: Everything Else**
- Condition: Fallback (ALL)
- Set variable: `priority = low`
- Set variable: `task_type = general_inquiry`

### Module 3: Get Client by Email
- URL: `https://your-site.netlify.app/api/webhooks/clients?email={{1.from.email}}`
- Method: `GET`
- Headers: `Authorization: Bearer YOUR_API_SECRET_KEY`

### Module 4: Create Task
- URL: `https://your-site.netlify.app/api/webhooks/task`
- Method: `POST`
- Headers:
  ```
  Authorization: Bearer YOUR_API_SECRET_KEY
  Content-Type: application/json
  ```
- Body:
  ```json
  {
    "action": "create",
    "client_id": "{{3.clients[0].id}}",
    "task_name": "{{Router.task_type}} - {{3.clients[0].name}}",
    "description": "Email: {{1.subject}}\n\n{{1.text}}",
    "priority": "{{Router.priority}}",
    "assigned_to": "{{3.clients[0].assigned_accountant}}",
    "created_by": "email_automation"
  }
  ```

### Module 5: Slack Notification
- Channel: `#tasks` or DM to assignee
- Message:
  ```
  📋 New task assigned to you!
  
  *{{4.task_name}}*
  Priority: {{Router.priority}}
  From: {{3.clients[0].name}}
  
  Check it out: https://your-site.netlify.app/admin/tasks
  ```

### Module 6: Auto-Reply
- To: `{{1.from.email}}`
- Subject: `Re: {{1.subject}}`
- Body:
  ```
  Hi {{3.clients[0].name}},
  
  Thanks for your email! We've received your message and {{3.clients[0].assigned_accountant}} will respond within 24 hours.
  
  You can always check your status here:
  {{3.clients[0].portal_url}}
  
  Best,
  Your Firm Name
  ```

---

## Scenario 3: Daily Document Reminder Check

**What it does:** Every day at 9am, check which clients are missing documents and haven't been reminded in the last 3 days. Send them a friendly reminder.

**Modules:**
1. Schedule → Every Day at 9:00 AM
2. HTTP → Get Clients with Missing Docs
3. Iterator (loop through clients)
4. Filter (only if needs reminder)
5. Gmail → Send Reminder
6. HTTP → Log Reminder Sent

**Configuration:**

### Module 2: Get Clients
- URL: `https://your-site.netlify.app/api/webhooks/clients?status=active`
- Method: `GET`
- Headers: `Authorization: Bearer YOUR_API_SECRET_KEY`

### Module 3: Iterator
- Array: `{{2.clients}}`

### Module 4: Filter
- Condition 1: `{{3.missing_documents}}` greater than `0`
- AND
- Condition 2: `{{3.last_contact_date}}` older than `3 days ago`

### Module 5: Gmail Reminder
- To: `{{3.email}}`
- Subject: `Quick reminder: We need a few documents 📄`
- Body:
  ```
  Hi {{3.name}}!
  
  Just a friendly reminder that we're still waiting for a few documents to complete your return.
  
  Missing documents: {{3.missing_documents}}
  
  Upload them here in 2 minutes:
  {{3.portal_url}}
  
  Or just reply to this email with them attached!
  
  Once we have everything, we'll have your return completed within 5 business days.
  
  Thanks!
  {{3.assigned_accountant}}
  ```

### Module 6: Log Reminder
- URL: `https://your-site.netlify.app/api/webhooks/document`
- Method: `POST`
- Headers:
  ```
  Authorization: Bearer YOUR_API_SECRET_KEY
  Content-Type: application/json
  ```
- Body:
  ```json
  {
    "client_id": "{{3.id}}",
    "document_type": "general",
    "status": "requested",
    "log_reminder": true
  }
  ```

---

## Scenario 4: Task Completed → Notify Client

**What it does:** When a staff member marks a task as "done" in the system, automatically email the client with an update.

**Modules:**
1. Schedule → Every 15 Minutes (poll for completed tasks)
2. HTTP → Get Recently Completed Tasks
3. Iterator
4. HTTP → Get Client Info
5. Gmail → Send Update Email
6. (Optional) Slack → Notify Team

**Configuration:**

### Module 2: Get Completed Tasks
- URL: `https://your-site.netlify.app/api/webhooks/tasks?status=done&updated_since=15minutes`
- Method: `GET`
- Headers: `Authorization: Bearer YOUR_API_SECRET_KEY`

### Module 3: Iterator
- Array: `{{2.tasks}}`

### Module 4: Get Client
- URL: `https://your-site.netlify.app/api/webhooks/clients?id={{3.client_id}}`
- Method: `GET`
- Headers: `Authorization: Bearer YOUR_API_SECRET_KEY`

### Module 5: Gmail Update
- To: `{{4.email}}`
- Subject: `Good news about your {{4.service_type}}! 🎉`
- Body:
  ```
  Hi {{4.name}},
  
  Great news! We just completed: {{3.task_name}}
  
  {{#if 3.task_type == "prepare_return"}}
  Your return is ready for review. Check it out here:
  {{4.portal_url}}
  {{else}}
  Check your portal for the latest update:
  {{4.portal_url}}
  {{/if}}
  
  Questions? Just reply to this email or give us a call!
  
  Best,
  {{4.assigned_accountant}}
  Your Firm Name
  ```

---

## Scenario 5: Lead to Client Conversion

**What it does:** When you mark a lead as "won" in your system, automatically create a client record, generate their portal, and send them a welcome email.

**Note:** This requires a trigger from your admin panel, which you'd set up later. For MVP, you can manually trigger this via Make.com webhook.

**Modules:**
1. Webhooks → Custom Webhook (trigger)
2. HTTP → Create Client in NexusFlow
3. HTTP → Create Initial Document Checklist
4. Gmail → Send Welcome Email
5. Slack → Notify Team

**Configuration:**

### Module 2: Create Client
- URL: `https://your-site.netlify.app/api/webhooks/client`
- Method: `POST`
- Body:
  ```json
  {
    "action": "create",
    "lead_id": "{{1.lead_id}}",
    "name": "{{1.name}}",
    "email": "{{1.email}}",
    "phone": "{{1.phone}}",
    "clientType": "{{1.client_type}}",
    "serviceType": "{{1.service_type}}",
    "assignedAccountant": "{{1.assigned_to}}",
    "securePortalUrl": "{{1.secure_portal_url}}"
  }
  ```

### Module 3: Create Document Checklist
(Multiple HTTP requests for each document type needed)

Example for Individual Tax Return:
```json
{
  "client_id": "{{2.client_id}}",
  "document_type": "w2",
  "status": "needed"
}
```

Repeat for: 1099, mortgage_interest, etc.

### Module 4: Welcome Email
- To: `{{1.email}}`
- Subject: `Welcome to {{FIRM_NAME}}! Here's what's next ✨`
- Body:
  ```
  Hi {{1.name}},
  
  Welcome! We're excited to work with you on your {{1.service_type}}.
  
  I've set up your personal portal where you can:
  • Upload documents securely
  • Check your status anytime
  • See what we still need from you
  
  👉 Your portal: {{2.portal_url}}
  
  Here's what I need from you to get started:
  • Your W-2 forms
  • Any 1099 forms you received
  • Mortgage interest statement (if you own a home)
  
  Just upload them to your portal or reply to this email with them attached.
  
  Once I have everything, I'll have your return completed within 5 business days.
  
  Questions? Text me at (555) 123-4567 anytime!
  
  Best,
  {{1.assigned_to}}
  {{FIRM_NAME}}
  ```

---

## Quick Setup Checklist

For each scenario above:

- [ ] Create new scenario in Make.com
- [ ] Add all modules in order
- [ ] Replace `YOUR_API_SECRET_KEY` with your actual key
- [ ] Replace `your-site.netlify.app` with your actual URL
- [ ] Replace firm name, phone, email with your details
- [ ] Test with dummy data first
- [ ] Turn on (activate) the scenario
- [ ] Monitor execution history for errors

---

## Pro Tips

### Testing Scenarios
- Use Make.com's "Run once" feature to test
- Check the execution history to debug issues
- Start with simple scenarios before complex ones

### Error Handling
- Add error handler modules to catch failed API calls
- Set up notifications when scenarios fail
- Keep logs of all executions for audit trail

### Efficiency
- Use filters to prevent unnecessary operations
- Schedule polling scenarios (don't run every minute)
- Combine multiple operations when possible

---

## Support

Can't get a scenario working?
1. Check Make.com execution history for errors
2. Verify your API key is correct
3. Test the API endpoint directly (use Postman or curl)
4. Check the README.md for API documentation

Happy automating! 🚀
