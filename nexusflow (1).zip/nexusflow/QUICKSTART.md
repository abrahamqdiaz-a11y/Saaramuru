# NexusFlow - Quick Start Checklist ✅

Follow these steps to get your NexusFlow MVP running in production.

## ⏱️ Time Required: ~30 minutes

---

## Step 1: Set Up Database (5 minutes)

- [ ] Go to [supabase.com](https://supabase.com)
- [ ] Create account (if needed)
- [ ] Click "New Project"
- [ ] Choose organization, name it "nexusflow", choose a strong password
- [ ] Wait 2 minutes for database to initialize
- [ ] Go to Settings → Database
- [ ] Copy "Connection string" (URI format)
- [ ] Save it somewhere - you'll need it soon!

Your connection string looks like:
```
postgresql://postgres:YOUR_PASSWORD@db.xxxx.supabase.co:5432/postgres
```

---

## Step 2: Generate Your Secrets (2 minutes)

### API Secret Key
Run this in your terminal:
```bash
openssl rand -hex 32
```

Or use: https://generate-random.org/api-key-generator

Save this - you'll use it twice (as `API_SECRET_KEY` and for the API key in database)

### Admin Password
Choose a strong password for accessing the admin dashboard.

---

## Step 3: Push to GitHub (5 minutes)

```bash
# Navigate to the nexusflow folder
cd nexusflow

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial NexusFlow MVP"

# Create a new repo on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

---

## Step 4: Deploy to Netlify (10 minutes)

- [ ] Go to [app.netlify.com](https://app.netlify.com)
- [ ] Click "Add new site" → "Import an existing project"
- [ ] Choose GitHub
- [ ] Select your nexusflow repository
- [ ] Build settings:
  - Build command: `npm run build`
  - Publish directory: `.next`
- [ ] **BEFORE clicking Deploy**, click "Add environment variables"
- [ ] Add these variables:

```
DATABASE_URL = your-supabase-connection-string-from-step-1
API_SECRET_KEY = your-generated-secret-key-from-step-2
NEXT_PUBLIC_APP_URL = (leave this blank for now, you'll update it)
ADMIN_PASSWORD = your-chosen-admin-password-from-step-2
NEXT_PUBLIC_FIRM_NAME = Your Firm Name
NEXT_PUBLIC_FIRM_EMAIL = hello@yourfirm.com
NEXT_PUBLIC_FIRM_PHONE = (555) 123-4567
```

- [ ] Click "Deploy site"
- [ ] Wait ~3 minutes for deployment
- [ ] Once deployed, copy your site URL (looks like: `https://random-name-123.netlify.app`)
- [ ] Go to Site settings → Environment variables
- [ ] Edit `NEXT_PUBLIC_APP_URL` and set it to your site URL
- [ ] Go to Deploys → Trigger deploy

---

## Step 5: Initialize Database (5 minutes)

### On your LOCAL computer:

```bash
# Navigate to your nexusflow folder
cd nexusflow

# Install dependencies
npm install

# Create .env.local file
cp .env.example .env.local
```

### Edit .env.local with your values:

```env
DATABASE_URL="your-supabase-connection-string"
API_SECRET_KEY="your-secret-key"
NEXT_PUBLIC_APP_URL="https://your-site.netlify.app"
ADMIN_PASSWORD="your-password"
NEXT_PUBLIC_FIRM_NAME="Your Firm Name"
NEXT_PUBLIC_FIRM_EMAIL="hello@yourfirm.com"
NEXT_PUBLIC_FIRM_PHONE="(555) 123-4567"
```

### Run these commands:

```bash
# Generate Prisma client
npx prisma generate

# Push database schema to Supabase
npx prisma db push

# Open Prisma Studio
npx prisma studio
```

### In Prisma Studio (browser window that opens):

- [ ] Click on "ApiKey" table
- [ ] Click "Add record"
- [ ] Fill in:
  - `keyName`: "Make.com Integration"
  - `apiKey`: (paste your API_SECRET_KEY)
  - `isActive`: true (check the box)
- [ ] Click "Save 1 change"

---

## Step 6: Test Your Deployment (3 minutes)

Visit these URLs (replace with your actual Netlify URL):

### Public Intake Form
`https://your-site.netlify.app/intake`

- [ ] Fill out the form with test data
- [ ] Submit - should see success message

### Admin Dashboard  
`https://your-site.netlify.app/admin`

- [ ] Should show your dashboard
- [ ] Check that your test lead appears

### Test Client Portal
You'll need to create a client first via the API, but the portal structure is ready!

---

## Step 7: Set Up Make.com (Optional - 10 minutes)

- [ ] Go to [make.com](https://make.com)
- [ ] Create account (free tier is fine)
- [ ] Create a new scenario
- [ ] Add "HTTP → Make a request" module
- [ ] Set:
  - URL: `https://your-site.netlify.app/api/webhooks/clients`
  - Method: GET
  - Headers: Add "Authorization" with value "Bearer YOUR_API_SECRET_KEY"
- [ ] Run it once - should return your clients
- [ ] Now you're ready to build automation!

---

## 🎉 You're Done!

Your NexusFlow MVP is live! Here's what you have:

✅ Public intake form at `/intake`
✅ Admin dashboard at `/admin`
✅ Client portals at `/portal/{token}`
✅ Webhook API ready for Make.com
✅ Database hosted on Supabase
✅ App deployed on Netlify

---

## Next Steps

### Embed the Form on Your Website

```html
<iframe
  src="https://your-site.netlify.app/intake"
  width="100%"
  height="800px"
  frameborder="0"
></iframe>
```

### Create Make.com Automations

See `README.md` for detailed Make.com scenario examples:
- Contact form → Create lead → Notify team
- Email → Create task → Assign to staff
- Daily document reminders

### Customize Branding

Update the environment variables in Netlify to change:
- Firm name
- Contact email
- Phone number

---

## Troubleshooting

### Site won't build on Netlify
- Check that all environment variables are set
- Make sure DATABASE_URL is the full connection string with password

### Can't see leads in admin dashboard
- Database might not be initialized
- Run `npx prisma db push` locally first

### API returns 401 errors
- API key not created in database
- Check you added the API key via Prisma Studio

### Need help?
Check the full README.md for detailed troubleshooting.

---

**Built and deployed in 30 minutes! 🚀**

Now start connecting your Gmail to Make.com and watch the magic happen!
