import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'
import { z } from 'zod'

const taskSchema = z.object({
  action: z.enum(['create', 'update']),
  task_id: z.string().optional(),
  client_id: z.string(),
  task_name: z.string().min(1),
  description: z.string().optional(),
  task_type: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  status: z.enum(['todo', 'in_progress', 'done', 'blocked']).optional(),
  assigned_to: z.string().optional(),
  due_date: z.string().optional(),
  created_by: z.string().optional(),
})

export async function POST(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const body = await request.json()
    const validatedData = taskSchema.parse(body)

    // Verify client exists
    const client = await prisma.client.findUnique({
      where: { id: validatedData.client_id },
    })

    if (!client) {
      return NextResponse.json(
        { success: false, error: 'Client not found' },
        { status: 404 }
      )
    }

    if (validatedData.action === 'create') {
      const task = await prisma.task.create({
        data: {
          clientId: validatedData.client_id,
          taskName: validatedData.task_name,
          description: validatedData.description,
          taskType: validatedData.task_type,
          priority: validatedData.priority || 'medium',
          status: validatedData.status || 'todo',
          assignedTo: validatedData.assigned_to,
          dueDate: validatedData.due_date ? new Date(validatedData.due_date) : null,
          createdBy: validatedData.created_by || 'system',
        },
      })

      // Update client's last contact date
      await prisma.client.update({
        where: { id: validatedData.client_id },
        data: { lastContactDate: new Date() },
      })

      return NextResponse.json({
        success: true,
        task_id: task.id,
        message: 'Task created successfully!',
      })
    } else if (validatedData.action === 'update') {
      if (!validatedData.task_id) {
        return NextResponse.json(
          { success: false, error: 'task_id is required for update action' },
          { status: 400 }
        )
      }

      const updateData: any = {
        taskName: validatedData.task_name,
        description: validatedData.description,
        taskType: validatedData.task_type,
        priority: validatedData.priority,
        status: validatedData.status,
        assignedTo: validatedData.assigned_to,
      }

      if (validatedData.due_date) {
        updateData.dueDate = new Date(validatedData.due_date)
      }

      // If marking as done, set completed timestamp
      if (validatedData.status === 'done') {
        updateData.completedAt = new Date()
      }

      const task = await prisma.task.update({
        where: { id: validatedData.task_id },
        data: updateData,
      })

      return NextResponse.json({
        success: true,
        task_id: task.id,
        message: 'Task updated successfully!',
      })
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Invalid data provided', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error with task:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to process task request' },
      { status: 500 }
    )
  }
}
