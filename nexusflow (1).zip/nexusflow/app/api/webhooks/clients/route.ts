import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'

export async function GET(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const assignedTo = searchParams.get('assigned_to')
    const updatedSince = searchParams.get('updated_since')

    const where: any = {}

    if (status) where.status = status
    if (assignedTo) where.assignedAccountant = assignedTo
    if (updatedSince) where.updatedAt = { gte: new Date(updatedSince) }

    const clients = await prisma.client.findMany({
      where,
      include: {
        documents: {
          where: {
            status: { in: ['needed', 'requested'] }
          }
        },
        tasks: {
          where: {
            status: { not: 'done' }
          }
        }
      },
      orderBy: { updatedAt: 'desc' },
      take: 100, // Limit to 100 clients per request
    })

    const formattedClients = clients.map(client => ({
      id: client.id,
      name: client.name,
      email: client.email,
      phone: client.phone,
      business_name: client.businessName,
      status: client.status,
      assigned_accountant: client.assignedAccountant,
      portal_url: `${process.env.NEXT_PUBLIC_APP_URL}/portal/${client.portalToken}`,
      portal_token: client.portalToken,
      missing_documents: client.documents.length,
      open_tasks: client.tasks.length,
      last_contact_date: client.lastContactDate,
      created_at: client.createdAt,
      updated_at: client.updatedAt,
    }))

    return NextResponse.json({
      success: true,
      count: formattedClients.length,
      clients: formattedClients,
    })
  } catch (error) {
    console.error('Error fetching clients:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch clients' },
      { status: 500 }
    )
  }
}
