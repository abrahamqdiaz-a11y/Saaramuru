# NexusFlow MVP

A personal, warm client management system for accounting firms. Turns chaotic inboxes into organized task lists while keeping client data secure.

## Features

- 📝 **Public Intake Form** - Embeddable contact form for your website
- 🔐 **Client Portal** - Unique, secure URLs for each client to check status
- 📊 **Admin Dashboard** - Beautiful, personal interface for managing leads, clients, and tasks
- 🔌 **Webhook API** - Easy integration with Make.com or n8n
- 🎨 **Warm Design** - Personal, friendly UI that feels like a human assistant

## Tech Stack

- **Frontend:** Next.js 14, TypeScript, Tailwind CSS, shadcn/ui
- **Database:** PostgreSQL (via Supabase)
- **Deployment:** Netlify (or Vercel)
- **Automation:** Make.com or n8n integration

---

## Quick Start

### 1. Prerequisites

- Node.js 18+ installed
- A Supabase account (free tier works)
- A GitHub account
- A Netlify account (free tier works)

### 2. Database Setup

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Wait for the database to initialize (~2 minutes)
3. Go to Project Settings → Database
4. Copy the "Connection string" (URI format)
5. Replace `[YOUR-PASSWORD]` in the connection string with your database password

Your connection string looks like:
```
postgresql://postgres:[YOUR-PASSWORD]@db.xxxxxxxxxxxxx.supabase.co:5432/postgres
```

### 3. Local Development Setup

```bash
# Clone your repo
git clone https://github.com/your-username/nexusflow.git
cd nexusflow

# Install dependencies
npm install

# Create .env.local file
cp .env.example .env.local
```

Edit `.env.local` with your values:

```env
DATABASE_URL="your-supabase-connection-string-here"
API_SECRET_KEY="generate-a-random-secret-key"
NEXT_PUBLIC_APP_URL="http://localhost:3000"
ADMIN_PASSWORD="choose-a-secure-password"
NEXT_PUBLIC_FIRM_NAME="Your Firm Name"
NEXT_PUBLIC_FIRM_EMAIL="hello@yourfirm.com"
NEXT_PUBLIC_FIRM_PHONE="(555) 123-4567"
```

**Generate a secure API key:**
```bash
# On Mac/Linux
openssl rand -hex 32

# Or use this online tool
# https://generate-random.org/api-key-generator
```

### 4. Initialize the Database

```bash
# Generate Prisma client
npx prisma generate

# Push database schema to Supabase
npx prisma db push

# (Optional) Open Prisma Studio to view your database
npx prisma studio
```

### 5. Create an API Key

You need to manually create an API key in your database for Make.com to use.

**Option A: Using Prisma Studio (easiest)**
```bash
npx prisma studio
```
1. Click on `ApiKey` table
2. Click "Add record"
3. Fill in:
   - `keyName`: "Make.com Integration"
   - `apiKey`: Use the same value as your `API_SECRET_KEY` from `.env.local`
   - `isActive`: true
4. Save

**Option B: Using Supabase SQL Editor**
1. Go to Supabase dashboard → SQL Editor
2. Run this query:
```sql
INSERT INTO api_keys (key_name, api_key, is_active)
VALUES ('Make.com Integration', 'your-api-secret-key-here', true);
```

### 6. Run Locally

```bash
npm run dev
```

Visit:
- Public intake form: http://localhost:3000/intake
- Admin dashboard: http://localhost:3000/admin
- Test client portal: http://localhost:3000/portal/test123 (won't work until you create a client)

---

## Deployment to Netlify

### 1. Push to GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### 2. Connect to Netlify

1. Go to [app.netlify.com](https://app.netlify.com)
2. Click "Add new site" → "Import an existing project"
3. Choose GitHub and select your repository
4. Build settings (should auto-detect):
   - Build command: `npm run build`
   - Publish directory: `.next`
5. Click "Deploy site"

### 3. Add Environment Variables

In Netlify:
1. Go to Site settings → Environment variables
2. Add each variable from your `.env.local` file:

```
DATABASE_URL = your-supabase-connection-string
API_SECRET_KEY = your-generated-secret-key
NEXT_PUBLIC_APP_URL = https://your-site-name.netlify.app
ADMIN_PASSWORD = your-chosen-password
NEXT_PUBLIC_FIRM_NAME = Your Firm Name
NEXT_PUBLIC_FIRM_EMAIL = hello@yourfirm.com
NEXT_PUBLIC_FIRM_PHONE = (555) 123-4567
```

3. Click "Save"
4. Go to "Deploys" and click "Trigger deploy"

### 4. Custom Domain (Optional)

1. In Netlify, go to Domain settings
2. Click "Add custom domain"
3. Follow instructions to point your domain to Netlify

---

## Make.com Integration

### Setting Up Webhooks

All API endpoints are at: `https://your-site.netlify.app/api/webhooks/`

**Authentication:** All requests require header:
```
Authorization: Bearer YOUR_API_SECRET_KEY
```

### Example Scenarios

#### Scenario 1: Contact Form → Create Lead

**Modules:**
1. **Webhooks → Custom Webhook** (trigger)
2. **HTTP → Make a Request**
   - URL: `https://your-site.netlify.app/api/webhooks/lead`
   - Method: POST
   - Headers:
     - `Authorization`: `Bearer YOUR_API_SECRET_KEY`
     - `Content-Type`: `application/json`
   - Body:
     ```json
     {
       "name": "{{1.name}}",
       "email": "{{1.email}}",
       "phone": "{{1.phone}}",
       "businessName": "{{1.businessName}}",
       "serviceType": "{{1.serviceType}}",
       "leadSource": "contact_form",
       "message": "{{1.message}}"
     }
     ```
3. **Gmail → Send an Email** (auto-reply to lead)
4. **Slack → Create a Message** (notify team)

#### Scenario 2: Email → Create Task

**Modules:**
1. **Gmail → Watch Emails**
2. **Router** (split by email subject/sender)
3. **HTTP → Make a Request** (Create Client if new)
   - URL: `https://your-site.netlify.app/api/webhooks/client`
   - Method: POST
4. **HTTP → Make a Request** (Create Task)
   - URL: `https://your-site.netlify.app/api/webhooks/task`
   - Method: POST
5. **Slack → Create a Message**

#### Scenario 3: Daily Document Reminder

**Modules:**
1. **Schedule → Every Day at 9am**
2. **HTTP → Make a Request** (Get clients with missing docs)
   - URL: `https://your-site.netlify.app/api/webhooks/clients`
   - Method: GET
   - Headers: `Authorization: Bearer YOUR_API_SECRET_KEY`
3. **Iterator** (loop through clients)
4. **Filter** (only if missing_documents > 0 AND last reminder > 3 days ago)
5. **Gmail → Send Email** (reminder to client)
6. **HTTP → Make a Request** (log reminder sent)
   - URL: `https://your-site.netlify.app/api/webhooks/document`
   - Body: `{ "client_id": "...", "document_type": "...", "status": "requested", "log_reminder": true }`

---

## API Reference

### POST /api/webhooks/lead
Create a new lead

**Body:**
```json
{
  "name": "Jennifer Smith",
  "email": "jennifer@example.com",
  "phone": "(555) 123-4567",
  "businessName": "Smith Consulting",
  "serviceType": "business_tax",
  "leadSource": "contact_form",
  "message": "Need help with taxes"
}
```

### POST /api/webhooks/client
Create or update a client

**Body:**
```json
{
  "action": "create",
  "name": "Jennifer Smith",
  "email": "jennifer@example.com",
  "phone": "(555) 123-4567",
  "clientType": "business",
  "serviceType": "business_tax",
  "assignedAccountant": "Tom Wilson",
  "securePortalUrl": "https://portal.example.com/jennifer"
}
```

**Response:**
```json
{
  "success": true,
  "client_id": "uuid",
  "portal_token": "abc123",
  "portal_url": "https://yourfirm.app/portal/abc123"
}
```

### POST /api/webhooks/task
Create or update a task

**Body:**
```json
{
  "action": "create",
  "client_id": "uuid",
  "task_name": "Review W-2 Documents",
  "priority": "high",
  "assigned_to": "Tom Wilson",
  "due_date": "2025-02-15"
}
```

### POST /api/webhooks/document
Update document status

**Body:**
```json
{
  "client_id": "uuid",
  "document_type": "w2",
  "status": "received",
  "log_reminder": false
}
```

### GET /api/webhooks/clients
List all clients (for polling)

**Query params:**
- `status=active` (optional)
- `assigned_to=Tom Wilson` (optional)

### GET /api/webhooks/tasks
List all tasks (for polling)

**Query params:**
- `status=todo` (optional)
- `priority=urgent` (optional)

---

## Embedding the Intake Form

Add this to your website:

```html
<iframe
  src="https://your-site.netlify.app/intake"
  width="100%"
  height="800px"
  frameborder="0"
></iframe>
```

Or link to it:
```html
<a href="https://your-site.netlify.app/intake">
  Get Started
</a>
```

---

## Customization

### Branding
Update environment variables:
- `NEXT_PUBLIC_FIRM_NAME`
- `NEXT_PUBLIC_FIRM_EMAIL`
- `NEXT_PUBLIC_FIRM_PHONE`

### Colors
Edit `app/globals.css` to change the color scheme

### Service Types
Edit the select options in:
- `app/intake/page.tsx` (public form)
- Webhook API validators in `app/api/webhooks/*/route.ts`

---

## Troubleshooting

### "Cannot find module '@prisma/client'"
```bash
npx prisma generate
```

### "Invalid `prisma.xxx.findMany()` invocation"
Your database isn't set up. Run:
```bash
npx prisma db push
```

### Webhooks returning 401 Unauthorized
- Check your API key is correct in Make.com
- Verify the API key exists in your database
- Make sure you're sending the `Authorization` header

### Client portal shows 404
- Client doesn't exist yet
- Portal token is wrong
- Check your database has the client record

---

## Development Roadmap

### Phase 1: MVP (Current)
- [x] Public intake form
- [x] Client portal
- [x] Admin dashboard
- [x] Webhook API
- [x] Basic task management

### Phase 2: Enhancements
- [ ] Email authentication (magic links)
- [ ] Better task filtering/search
- [ ] Document upload to S3
- [ ] Email templates library
- [ ] Reporting/analytics

### Phase 3: Scale Features
- [ ] Multi-firm support
- [ ] Team permissions
- [ ] QuickBooks sync
- [ ] Calendar integration
- [ ] Mobile app

---

## Support

Questions? Issues? Reach out:
- GitHub Issues: [your-repo/issues](https://github.com/your-username/nexusflow/issues)
- Email: your-email@example.com

---

## License

MIT License - feel free to use this for your firm!

---

Built with ❤️ for accounting firms who deserve better tools.
