import { Suspense } from 'react'
import Link from 'next/link'
import prisma from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getGreeting, formatDate, getPriorityColor, isOverdue } from '@/lib/utils'
import { Users, CheckSquare, FileText, AlertCircle, ArrowRight } from 'lucide-react'

async function getDashboardStats() {
  const [
    totalClients,
    activeClients,
    totalLeads,
    newLeads,
    totalTasks,
    urgentTasks,
    overdueTasks,
    tasksToday,
  ] = await Promise.all([
    prisma.client.count(),
    prisma.client.count({ where: { status: 'active' } }),
    prisma.lead.count(),
    prisma.lead.count({ where: { status: 'new' } }),
    prisma.task.count({ where: { status: { not: 'done' } } }),
    prisma.task.count({ where: { priority: 'urgent', status: { not: 'done' } } }),
    prisma.task.count({
      where: {
        status: { not: 'done' },
        dueDate: { lt: new Date() }
      }
    }),
    prisma.task.count({
      where: {
        status: { not: 'done' },
        dueDate: {
          gte: new Date(new Date().setHours(0, 0, 0, 0)),
          lt: new Date(new Date().setHours(23, 59, 59, 999))
        }
      }
    }),
  ])

  return {
    totalClients,
    activeClients,
    totalLeads,
    newLeads,
    totalTasks,
    urgentTasks,
    overdueTasks,
    tasksToday,
  }
}

async function getRecentActivity() {
  const recentLeads = await prisma.lead.findMany({
    where: { status: 'new' },
    orderBy: { createdAt: 'desc' },
    take: 3,
  })

  const urgentTasks = await prisma.task.findMany({
    where: {
      priority: 'urgent',
      status: { not: 'done' }
    },
    include: {
      client: {
        select: { name: true, email: true }
      }
    },
    orderBy: { createdAt: 'desc' },
    take: 5,
  })

  return { recentLeads, urgentTasks }
}

export default async function AdminDashboard() {
  const stats = await getDashboardStats()
  const { recentLeads, urgentTasks } = await getRecentActivity()

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-stone-900">
                {getGreeting()}! ☀️
              </h1>
              <p className="text-stone-600 mt-1">
                {stats.tasksToday === 0
                  ? "You have a light day ahead—time to catch up!"
                  : stats.tasksToday === 1
                  ? "You have 1 task due today"
                  : `You have ${stats.tasksToday} tasks due today`}
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" asChild>
                <Link href="/admin/clients">View Clients</Link>
              </Button>
              <Button asChild>
                <Link href="/admin/tasks">View Tasks</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Clients</CardTitle>
              <Users className="h-4 w-4 text-stone-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.activeClients}</div>
              <p className="text-xs text-stone-600 mt-1">
                {stats.totalClients} total clients
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">New Leads</CardTitle>
              <FileText className="h-4 w-4 text-stone-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.newLeads}</div>
              <p className="text-xs text-stone-600 mt-1">
                {stats.totalLeads} total leads
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Open Tasks</CardTitle>
              <CheckSquare className="h-4 w-4 text-stone-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalTasks}</div>
              <p className="text-xs text-stone-600 mt-1">
                {stats.urgentTasks} urgent
              </p>
            </CardContent>
          </Card>

          <Card className={stats.overdueTasks > 0 ? 'border-red-200 bg-red-50' : ''}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overdue Tasks</CardTitle>
              <AlertCircle className={`h-4 w-4 ${stats.overdueTasks > 0 ? 'text-red-600' : 'text-stone-600'}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-3xl font-bold ${stats.overdueTasks > 0 ? 'text-red-600' : ''}`}>
                {stats.overdueTasks}
              </div>
              <p className="text-xs text-stone-600 mt-1">
                {stats.overdueTasks === 0 ? 'Great job! 🎉' : 'Need attention'}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Your Focus Today */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                🎯 Your Focus Today
              </CardTitle>
              <CardDescription>
                {urgentTasks.length === 0
                  ? "No urgent tasks—you're all caught up!"
                  : urgentTasks.length === 1
                  ? "1 urgent task needs your attention"
                  : `${urgentTasks.length} urgent tasks need your attention`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {urgentTasks.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-5xl mb-4">✨</p>
                  <p className="text-stone-600">
                    Wow, you're all caught up!
                  </p>
                  <p className="text-sm text-stone-500 mt-2">
                    Time for that coffee break? ☕
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {urgentTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-4 bg-red-50 border border-red-200 rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-stone-900">{task.taskName}</h4>
                          <p className="text-sm text-stone-600 mt-1">
                            {task.client.name}
                          </p>
                          {task.dueDate && (
                            <p className="text-xs text-stone-500 mt-1">
                              Due: {formatDate(task.dueDate)}
                              {isOverdue(task.dueDate) && ' (overdue)'}
                            </p>
                          )}
                        </div>
                        <Button size="sm" variant="outline" asChild>
                          <Link href={`/admin/tasks`}>
                            View
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                  <Button className="w-full" variant="outline" asChild>
                    <Link href="/admin/tasks">
                      View All Tasks <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* New Messages / Leads */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                💬 New Messages
              </CardTitle>
              <CardDescription>
                {recentLeads.length === 0
                  ? "No new leads right now"
                  : recentLeads.length === 1
                  ? "1 person just reached out"
                  : `${recentLeads.length} people just reached out`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentLeads.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-5xl mb-4">📭</p>
                  <p className="text-stone-600">
                    No new leads yet
                  </p>
                  <p className="text-sm text-stone-500 mt-2">
                    Check back soon!
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentLeads.map((lead) => (
                    <div
                      key={lead.id}
                      className="p-4 bg-blue-50 border border-blue-200 rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-stone-900">{lead.name}</h4>
                          <p className="text-sm text-stone-600 mt-1">
                            {lead.serviceType?.replace('_', ' ')} • {formatDate(lead.createdAt)}
                          </p>
                          {lead.message && (
                            <p className="text-sm text-stone-600 mt-2 italic line-clamp-2">
                              "{lead.message}"
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button className="w-full" variant="outline" asChild>
                    <Link href="/admin/leads">
                      View All Leads <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-auto py-4" asChild>
                <Link href="/admin/leads" className="flex flex-col items-center gap-2">
                  <FileText className="h-6 w-6" />
                  <span>View Leads</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4" asChild>
                <Link href="/admin/clients" className="flex flex-col items-center gap-2">
                  <Users className="h-6 w-6" />
                  <span>View Clients</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4" asChild>
                <Link href="/admin/tasks" className="flex flex-col items-center gap-2">
                  <CheckSquare className="h-6 w-6" />
                  <span>View Tasks</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
