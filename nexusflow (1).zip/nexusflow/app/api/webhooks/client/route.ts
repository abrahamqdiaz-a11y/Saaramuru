import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'
import { generatePortalToken } from '@/lib/utils'
import { z } from 'zod'

const clientSchema = z.object({
  action: z.enum(['create', 'update']),
  client_id: z.string().optional(),
  lead_id: z.string().optional(),
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  businessName: z.string().optional(),
  clientType: z.string().optional(),
  serviceType: z.string().optional(),
  assignedAccountant: z.string().optional(),
  securePortalUrl: z.string().optional(),
  quickbooksId: z.string().optional(),
})

export async function POST(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const body = await request.json()
    const validatedData = clientSchema.parse(body)

    if (validatedData.action === 'create') {
      const portalToken = generatePortalToken()
      
      const client = await prisma.client.create({
        data: {
          leadId: validatedData.lead_id,
          name: validatedData.name,
          email: validatedData.email,
          phone: validatedData.phone,
          businessName: validatedData.businessName,
          clientType: validatedData.clientType,
          serviceType: validatedData.serviceType,
          assignedAccountant: validatedData.assignedAccountant,
          securePortalUrl: validatedData.securePortalUrl,
          quickbooksId: validatedData.quickbooksId,
          portalToken,
          status: 'active',
        },
      })

      // If created from a lead, update lead status
      if (validatedData.lead_id) {
        await prisma.lead.update({
          where: { id: validatedData.lead_id },
          data: { status: 'won' },
        })
      }

      const portalUrl = `${process.env.NEXT_PUBLIC_APP_URL}/portal/${portalToken}`

      return NextResponse.json({
        success: true,
        client_id: client.id,
        portal_token: portalToken,
        portal_url: portalUrl,
        message: 'Client created successfully!',
      })
    } else if (validatedData.action === 'update') {
      if (!validatedData.client_id) {
        return NextResponse.json(
          { success: false, error: 'client_id is required for update action' },
          { status: 400 }
        )
      }

      const client = await prisma.client.update({
        where: { id: validatedData.client_id },
        data: {
          name: validatedData.name,
          email: validatedData.email,
          phone: validatedData.phone,
          businessName: validatedData.businessName,
          clientType: validatedData.clientType,
          serviceType: validatedData.serviceType,
          assignedAccountant: validatedData.assignedAccountant,
          securePortalUrl: validatedData.securePortalUrl,
          quickbooksId: validatedData.quickbooksId,
          lastContactDate: new Date(),
        },
      })

      const portalUrl = `${process.env.NEXT_PUBLIC_APP_URL}/portal/${client.portalToken}`

      return NextResponse.json({
        success: true,
        client_id: client.id,
        portal_url: portalUrl,
        message: 'Client updated successfully!',
      })
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Invalid data provided', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error with client:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to process client request' },
      { status: 500 }
    )
  }
}
