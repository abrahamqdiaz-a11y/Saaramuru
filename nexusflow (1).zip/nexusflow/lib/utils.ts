import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generatePortalToken(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15)
}

export function formatDate(date: Date | string | null): string {
  if (!date) return 'Not set'
  const d = new Date(date)
  return d.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric' 
  })
}

export function formatDateTime(date: Date | string | null): string {
  if (!date) return 'Not set'
  const d = new Date(date)
  return d.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  })
}

export function getPriorityColor(priority: string): string {
  switch (priority) {
    case 'urgent': return 'text-red-600 bg-red-50 border-red-200'
    case 'high': return 'text-orange-600 bg-orange-50 border-orange-200'
    case 'medium': return 'text-blue-600 bg-blue-50 border-blue-200'
    case 'low': return 'text-stone-600 bg-stone-50 border-stone-200'
    default: return 'text-stone-600 bg-stone-50 border-stone-200'
  }
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'done': 
    case 'completed': 
    case 'received': return 'text-green-600 bg-green-50 border-green-200'
    case 'in_progress': 
    case 'in progress': return 'text-blue-600 bg-blue-50 border-blue-200'
    case 'todo': 
    case 'needed': return 'text-stone-600 bg-stone-50 border-stone-200'
    case 'blocked': return 'text-red-600 bg-red-50 border-red-200'
    default: return 'text-stone-600 bg-stone-50 border-stone-200'
  }
}

export function getGreeting(): string {
  const hour = new Date().getHours()
  if (hour < 12) return 'Good morning'
  if (hour < 18) return 'Good afternoon'
  return 'Good evening'
}

export function isOverdue(dueDate: Date | string | null): boolean {
  if (!dueDate) return false
  return new Date(dueDate) < new Date()
}
