import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'
import { z } from 'zod'

const leadSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  businessName: z.string().optional(),
  serviceType: z.string().optional(),
  leadSource: z.string().optional(),
  message: z.string().optional(),
})

export async function POST(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const body = await request.json()
    const validatedData = leadSchema.parse(body)

    const lead = await prisma.lead.create({
      data: {
        name: validatedData.name,
        email: validatedData.email,
        phone: validatedData.phone,
        businessName: validatedData.businessName,
        serviceType: validatedData.serviceType,
        leadSource: validatedData.leadSource || 'contact_form',
        message: validatedData.message,
        status: 'new',
      },
    })

    return NextResponse.json({
      success: true,
      lead_id: lead.id,
      message: 'Lead created successfully!',
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Invalid data provided', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error creating lead:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create lead' },
      { status: 500 }
    )
  }
}
