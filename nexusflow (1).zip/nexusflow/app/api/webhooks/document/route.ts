import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'
import { z } from 'zod'

const documentSchema = z.object({
  client_id: z.string(),
  document_type: z.string(),
  document_name: z.string().optional(),
  status: z.enum(['needed', 'requested', 'received', 'reviewed']),
  notes: z.string().optional(),
  log_reminder: z.boolean().optional(),
})

export async function POST(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const body = await request.json()
    const validatedData = documentSchema.parse(body)

    // Verify client exists
    const client = await prisma.client.findUnique({
      where: { id: validatedData.client_id },
    })

    if (!client) {
      return NextResponse.json(
        { success: false, error: 'Client not found' },
        { status: 404 }
      )
    }

    // Check if document already exists
    const existingDoc = await prisma.document.findFirst({
      where: {
        clientId: validatedData.client_id,
        documentType: validatedData.document_type,
      },
    })

    let document

    if (existingDoc) {
      // Update existing document
      const updateData: any = {
        status: validatedData.status,
        notes: validatedData.notes,
      }

      if (validatedData.status === 'received') {
        updateData.receivedAt = new Date()
      }

      if (validatedData.log_reminder) {
        updateData.lastReminderSent = new Date()
        updateData.reminderCount = existingDoc.reminderCount + 1
      }

      document = await prisma.document.update({
        where: { id: existingDoc.id },
        data: updateData,
      })
    } else {
      // Create new document record
      document = await prisma.document.create({
        data: {
          clientId: validatedData.client_id,
          documentType: validatedData.document_type,
          documentName: validatedData.document_name,
          status: validatedData.status,
          notes: validatedData.notes,
          requestedAt: new Date(),
          receivedAt: validatedData.status === 'received' ? new Date() : null,
          lastReminderSent: validatedData.log_reminder ? new Date() : null,
          reminderCount: validatedData.log_reminder ? 1 : 0,
        },
      })
    }

    // Check if all documents for this client are received
    const allDocuments = await prisma.document.findMany({
      where: { clientId: validatedData.client_id },
    })

    const allReceived = allDocuments.every(doc => doc.status === 'received' || doc.status === 'reviewed')
    const missingCount = allDocuments.filter(doc => doc.status === 'needed' || doc.status === 'requested').length

    return NextResponse.json({
      success: true,
      document_id: document.id,
      all_documents_received: allReceived,
      missing_documents_count: missingCount,
      message: 'Document status updated successfully!',
    })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Invalid data provided', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Error with document:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update document status' },
      { status: 500 }
    )
  }
}
