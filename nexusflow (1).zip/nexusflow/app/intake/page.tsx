'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function IntakePage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    businessName: '',
    serviceType: '',
    message: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // In production, this would call your webhook directly
    // For now, we'll simulate a submission
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubmitted(true)
    }, 1500)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg animate-scale-in">
          <CardHeader className="text-center space-y-4">
            <div className="text-6xl">🎉</div>
            <CardTitle className="text-2xl">Thanks for reaching out!</CardTitle>
            <CardDescription className="text-base">
              We got your message and someone from our team will get back to you within 24 hours.
              <br /><br />
              In the meantime, feel free to text us at{' '}
              <span className="font-semibold text-blue-600">
                {process.env.NEXT_PUBLIC_FIRM_PHONE || '(555) 123-4567'}
              </span>{' '}
              if it's urgent!
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-sm text-stone-500">
              – The {process.env.NEXT_PUBLIC_FIRM_NAME || 'NexusFlow'} Team
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-stone-900 mb-3">
            Let's work together! ✨
          </h1>
          <p className="text-lg text-stone-600">
            Tell us a bit about yourself and we'll be in touch soon
          </p>
        </div>

        <Card className="animate-slide-in-up">
          <CardHeader>
            <CardTitle>Get Started</CardTitle>
            <CardDescription>
              Fill out the form below and we'll reach out within 24 hours
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">What's your name? *</Label>
                <Input
                  id="name"
                  placeholder="Jennifer Smith"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">What's your email? *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="jennifer@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
                <p className="text-sm text-stone-500">
                  We'll send updates here—promise not to spam! ✌️
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone number (optional)</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(555) 123-4567"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessName">Business name (if applicable)</Label>
                <Input
                  id="businessName"
                  placeholder="Smith Consulting LLC"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="serviceType">What service do you need? *</Label>
                <Select
                  value={formData.serviceType}
                  onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a service" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual_tax">Individual Tax Return</SelectItem>
                    <SelectItem value="business_tax">Business Tax Return</SelectItem>
                    <SelectItem value="bookkeeping">Bookkeeping</SelectItem>
                    <SelectItem value="business_formation">Business Formation</SelectItem>
                    <SelectItem value="tax_planning">Tax Planning</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Tell us about your situation</Label>
                <Textarea
                  id="message"
                  placeholder="I need help with..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={4}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Sending...' : 'Send My Information'}
              </Button>

              <p className="text-sm text-center text-stone-500">
                By submitting, you agree to let us contact you about your inquiry
              </p>
            </form>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-stone-500 animate-fade-in animation-delay-200">
          <p>
            Questions? Call us at{' '}
            <a
              href={`tel:${process.env.NEXT_PUBLIC_FIRM_PHONE}`}
              className="text-blue-600 hover:underline"
            >
              {process.env.NEXT_PUBLIC_FIRM_PHONE || '(555) 123-4567'}
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
