import { notFound } from 'next/navigation'
import prisma from '@/lib/db'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { formatDate } from '@/lib/utils'
import { CheckCircle2, Clock, Mail, Phone, ExternalLink } from 'lucide-react'

interface PageProps {
  params: {
    token: string
  }
}

export default async function ClientPortalPage({ params }: PageProps) {
  const { token } = params

  const client = await prisma.client.findUnique({
    where: { portalToken: token },
    include: {
      documents: {
        orderBy: { createdAt: 'asc' }
      },
      tasks: {
        where: {
          status: { not: 'done' }
        },
        orderBy: { createdAt: 'desc' },
        take: 5
      }
    }
  })

  if (!client) {
    notFound()
  }

  const receivedDocs = client.documents.filter(d => d.status === 'received' || d.status === 'reviewed')
  const neededDocs = client.documents.filter(d => d.status === 'needed' || d.status === 'requested')
  const progress = client.documents.length > 0
    ? Math.round((receivedDocs.length / client.documents.length) * 100)
    : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 py-12 px-4">
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Welcome Header */}
        <div className="text-center space-y-3 animate-fade-in">
          <h1 className="text-4xl font-bold text-stone-900">
            Hi {client.name.split(' ')[0]}! 👋
          </h1>
          <p className="text-lg text-stone-600">
            Here's where we're at with your {client.serviceType?.replace('_', ' ')}
          </p>
        </div>

        {/* Progress Card */}
        <Card className="animate-slide-in-up">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {progress === 100 ? '🎉' : '📋'} Your Progress
            </CardTitle>
            <CardDescription>
              {progress === 100
                ? "We have everything we need! We're working on your return now."
                : "We're making progress—here's what we still need from you"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-stone-600">Documents received</span>
                <span className="font-semibold text-stone-900">{progress}%</span>
              </div>
              <div className="h-3 bg-stone-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {client.assignedAccountant && (
              <p className="text-sm text-stone-600">
                {client.assignedAccountant} is handling your account
              </p>
            )}
          </CardContent>
        </Card>

        {/* Documents Section */}
        {client.documents.length > 0 && (
          <Card className="animate-slide-in-up animation-delay-200">
            <CardHeader>
              <CardTitle>Documents</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Received Documents */}
              {receivedDocs.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-stone-700">What we have:</h4>
                  {receivedDocs.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg"
                    >
                      <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="font-medium text-stone-900">
                          {doc.documentName || doc.documentType}
                        </p>
                        <p className="text-sm text-stone-600">
                          Received {formatDate(doc.receivedAt)} — looks great!
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Needed Documents */}
              {neededDocs.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-stone-700">What we still need:</h4>
                  {neededDocs.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg"
                    >
                      <Clock className="h-5 w-5 text-orange-600 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="font-medium text-stone-900">
                          {doc.documentName || doc.documentType}
                        </p>
                        {doc.notes && (
                          <p className="text-sm text-stone-600">{doc.notes}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Upload Section */}
        <Card className="animate-slide-in-up animation-delay-400 border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle>Need to send us something?</CardTitle>
            <CardDescription className="text-stone-700">
              Upload documents to your secure portal, or just email them to us
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {client.securePortalUrl ? (
              <Button className="w-full" size="lg" asChild>
                <a href={client.securePortalUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Open Your Secure Portal
                </a>
              </Button>
            ) : (
              <div className="space-y-2">
                <p className="text-sm text-stone-600">
                  Email your documents to:
                </p>
                <a
                  href={`mailto:${process.env.NEXT_PUBLIC_FIRM_EMAIL}?subject=Documents for ${client.name}`}
                  className="flex items-center gap-2 p-4 bg-white border-2 border-stone-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
                >
                  <Mail className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-stone-900">
                    {process.env.NEXT_PUBLIC_FIRM_EMAIL || 'docs@yourfirm.com'}
                  </span>
                </a>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Contact Section */}
        <Card className="animate-slide-in-up animation-delay-600">
          <CardHeader>
            <CardTitle>Questions?</CardTitle>
            <CardDescription>
              We're here to help! Reach out anytime
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <a
              href={`tel:${process.env.NEXT_PUBLIC_FIRM_PHONE}`}
              className="flex items-center gap-3 p-4 bg-stone-50 border border-stone-200 rounded-xl hover:bg-stone-100 transition-all duration-200"
            >
              <Phone className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-stone-900">Text or call us</p>
                <p className="text-sm text-stone-600">
                  {process.env.NEXT_PUBLIC_FIRM_PHONE || '(555) 123-4567'}
                </p>
              </div>
            </a>

            <a
              href={`mailto:${process.env.NEXT_PUBLIC_FIRM_EMAIL}?subject=Question from ${client.name}`}
              className="flex items-center gap-3 p-4 bg-stone-50 border border-stone-200 rounded-xl hover:bg-stone-100 transition-all duration-200"
            >
              <Mail className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-stone-900">Send us an email</p>
                <p className="text-sm text-stone-600">
                  {process.env.NEXT_PUBLIC_FIRM_EMAIL || 'hello@yourfirm.com'}
                </p>
              </div>
            </a>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-stone-500 animate-fade-in animation-delay-800">
          <p>
            Last updated: {formatDate(client.updatedAt)}
          </p>
          <p className="mt-2">
            Powered by {process.env.NEXT_PUBLIC_FIRM_NAME || 'NexusFlow'}
          </p>
        </div>
      </div>
    </div>
  )
}
