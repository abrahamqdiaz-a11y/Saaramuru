import Link from 'next/link'
import prisma from '@/lib/db'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatDate } from '@/lib/utils'
import { ArrowLeft, ExternalLink } from 'lucide-react'

export default async function AdminClientsPage() {
  const clients = await prisma.client.findMany({
    include: {
      documents: {
        where: {
          status: { in: ['needed', 'requested'] }
        }
      },
      tasks: {
        where: {
          status: { not: 'done' }
        }
      }
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="ghost" asChild className="mb-2">
                <Link href="/admin">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Dashboard
                </Link>
              </Button>
              <h1 className="text-3xl font-bold text-stone-900">Clients</h1>
              <p className="text-stone-600 mt-1">
                {clients.length} total clients
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>All Clients</CardTitle>
            <CardDescription>
              Your active and archived clients
            </CardDescription>
          </CardHeader>
          <CardContent>
            {clients.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-stone-600">No clients yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-stone-200">
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Name</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Email</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Service</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Assigned To</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Status</th>
                      <th className="text-left py-3 px-4 font-semibold text-stone-700">Portal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clients.map((client) => (
                      <tr key={client.id} className="border-b border-stone-100 hover:bg-stone-50">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-stone-900">{client.name}</p>
                            {client.businessName && (
                              <p className="text-sm text-stone-500">{client.businessName}</p>
                            )}
                            {client.documents.length > 0 && (
                              <p className="text-xs text-orange-600 mt-1">
                                {client.documents.length} missing docs
                              </p>
                            )}
                            {client.tasks.length > 0 && (
                              <p className="text-xs text-blue-600 mt-1">
                                {client.tasks.length} open tasks
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-stone-600">{client.email}</td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-700">
                            {client.serviceType?.replace('_', ' ') || 'Not specified'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-stone-600">
                          {client.assignedAccountant || '—'}
                        </td>
                        <td className="py-3 px-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${
                            client.status === 'active' ? 'bg-green-50 text-green-700' :
                            'bg-stone-100 text-stone-600'
                          }`}>
                            {client.status}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <Button variant="ghost" size="sm" asChild>
                            <Link
                              href={`/portal/${client.portalToken}`}
                              target="_blank"
                              className="flex items-center gap-1"
                            >
                              <ExternalLink className="h-3 w-3" />
                              View
                            </Link>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
