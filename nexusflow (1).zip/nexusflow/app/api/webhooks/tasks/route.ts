import { NextRequest, NextResponse } from 'next/server'
import { validateApiKey, unauthorized } from '@/lib/auth'
import prisma from '@/lib/db'

export async function GET(request: NextRequest) {
  // Validate API key
  const isValid = await validateApiKey(request)
  if (!isValid) {
    return unauthorized()
  }

  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const assignedTo = searchParams.get('assigned_to')
    const priority = searchParams.get('priority')
    const clientId = searchParams.get('client_id')

    const where: any = {}

    if (status) where.status = status
    if (assignedTo) where.assignedTo = assignedTo
    if (priority) where.priority = priority
    if (clientId) where.clientId = clientId

    const tasks = await prisma.task.findMany({
      where,
      include: {
        client: {
          select: {
            name: true,
            email: true,
            phone: true,
          }
        }
      },
      orderBy: [
        { priority: 'desc' },
        { dueDate: 'asc' },
      ],
      take: 100, // Limit to 100 tasks per request
    })

    const formattedTasks = tasks.map(task => ({
      id: task.id,
      task_name: task.taskName,
      description: task.description,
      task_type: task.taskType,
      priority: task.priority,
      status: task.status,
      assigned_to: task.assignedTo,
      due_date: task.dueDate,
      completed_at: task.completedAt,
      created_by: task.createdBy,
      created_at: task.createdAt,
      updated_at: task.updatedAt,
      client: {
        id: task.clientId,
        name: task.client.name,
        email: task.client.email,
        phone: task.client.phone,
      },
      is_overdue: task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done',
    }))

    return NextResponse.json({
      success: true,
      count: formattedTasks.length,
      tasks: formattedTasks,
    })
  } catch (error) {
    console.error('Error fetching tasks:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tasks' },
      { status: 500 }
    )
  }
}
