import Link from 'next/link'
import prisma from '@/lib/db'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatDate, getPriorityColor, isOverdue } from '@/lib/utils'
import { ArrowLeft } from 'lucide-react'

export default async function AdminTasksPage() {
  const tasks = await prisma.task.findMany({
    where: {
      status: { not: 'done' }
    },
    include: {
      client: {
        select: {
          name: true,
          email: true,
        }
      }
    },
    orderBy: [
      { priority: 'desc' },
      { dueDate: 'asc' },
    ],
    take: 100,
  })

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-white border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="ghost" asChild className="mb-2">
                <Link href="/admin">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Dashboard
                </Link>
              </Button>
              <h1 className="text-3xl font-bold text-stone-900">Tasks</h1>
              <p className="text-stone-600 mt-1">
                {tasks.length} open tasks
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Open Tasks</CardTitle>
            <CardDescription>
              All tasks that need attention, sorted by priority
            </CardDescription>
          </CardHeader>
          <CardContent>
            {tasks.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-5xl mb-4">✨</p>
                <p className="text-stone-900 font-semibold mb-2">
                  Wow, you're all caught up!
                </p>
                <p className="text-stone-600">
                  No open tasks right now
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {tasks.map((task) => (
                  <div
                    key={task.id}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      task.priority === 'urgent'
                        ? 'bg-red-50 border-red-200'
                        : task.priority === 'high'
                        ? 'bg-orange-50 border-orange-200'
                        : 'bg-white border-stone-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                            {task.priority}
                          </span>
                          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-stone-100 text-stone-700">
                            {task.status.replace('_', ' ')}
                          </span>
                          {task.dueDate && isOverdue(task.dueDate) && (
                            <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-red-100 text-red-700">
                              OVERDUE
                            </span>
                          )}
                        </div>
                        <h3 className="font-semibold text-stone-900 text-lg mb-1">
                          {task.taskName}
                        </h3>
                        <p className="text-sm text-stone-600 mb-2">
                          Client: {task.client.name}
                        </p>
                        {task.description && (
                          <p className="text-sm text-stone-600 mb-2">
                            {task.description}
                          </p>
                        )}
                        <div className="flex items-center gap-4 text-xs text-stone-500">
                          {task.assignedTo && (
                            <span>Assigned to: {task.assignedTo}</span>
                          )}
                          {task.dueDate && (
                            <span>Due: {formatDate(task.dueDate)}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
